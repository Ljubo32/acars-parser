"""
Simple Tkinter GUI wrapper for acars_parser.exe (extract command).
- Select input JSONL
- Select output JSON
- Options: pretty, all
- Run and view stdout/stderr

Requirements: Python 3.x (standard library only).
"""
import os
import threading
import subprocess
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ACARS Parser — GUI (extract)")
        self.geometry("980x640")

        self.exe_var = tk.StringVar(value=r".\acars_parser.exe")
        self.in_var = tk.StringVar()
        self.out_var = tk.StringVar()
        self.pretty_var = tk.BooleanVar(value=True)
        self.all_var = tk.BooleanVar(value=True)
        self.stats_var = tk.BooleanVar(value=True)

        self._build_ui()

    def _build_ui(self):
        frm = ttk.Frame(self, padding=10)
        frm.pack(fill="both", expand=True)

        # Row: exe
        row0 = ttk.Frame(frm)
        row0.pack(fill="x", pady=(0,6))
        ttk.Label(row0, text="acars_parser executable:").pack(side="left")
        ttk.Entry(row0, textvariable=self.exe_var, width=70).pack(side="left", padx=6, fill="x", expand=True)
        ttk.Button(row0, text="Browse…", command=self.pick_exe).pack(side="left")

        # Row: input
        row1 = ttk.Frame(frm)
        row1.pack(fill="x", pady=6)
        ttk.Label(row1, text="Input JSONL:").pack(side="left")
        ttk.Entry(row1, textvariable=self.in_var, width=70).pack(side="left", padx=6, fill="x", expand=True)
        ttk.Button(row1, text="Browse…", command=self.pick_input).pack(side="left")

        # Row: output
        row2 = ttk.Frame(frm)
        row2.pack(fill="x", pady=6)
        ttk.Label(row2, text="Output JSON:").pack(side="left")
        ttk.Entry(row2, textvariable=self.out_var, width=70).pack(side="left", padx=6, fill="x", expand=True)
        ttk.Button(row2, text="Browse…", command=self.pick_output).pack(side="left")

        # Row: options + run
        row3 = ttk.Frame(frm)
        row3.pack(fill="x", pady=6)
        ttk.Checkbutton(row3, text="Pretty", variable=self.pretty_var).pack(side="left")
        ttk.Checkbutton(row3, text="All (include unparsed)", variable=self.all_var).pack(side="left", padx=(10,0))
        ttk.Checkbutton(row3, text="Stats (stderr)", variable=self.stats_var).pack(side="left", padx=(10,0))
        ttk.Button(row3, text="Run Extract", command=self.run_extract).pack(side="right")

        # Output text
        self.txt = tk.Text(frm, wrap="none")
        self.txt.pack(fill="both", expand=True, pady=(10,0))

        # Scrollbars
        xscroll = ttk.Scrollbar(frm, orient="horizontal", command=self.txt.xview)
        xscroll.pack(fill="x")
        yscroll = ttk.Scrollbar(frm, orient="vertical", command=self.txt.yview)
        yscroll.place(relx=1.0, rely=0.22, relheight=0.75, anchor="ne")  # minimal intrusion
        self.txt.configure(xscrollcommand=xscroll.set, yscrollcommand=yscroll.set)

    def pick_exe(self):
        path = filedialog.askopenfilename(title="Select acars_parser executable", filetypes=[("Executable","*.exe"),("All","*.*")])
        if path:
            self.exe_var.set(path)

    def pick_input(self):
        path = filedialog.askopenfilename(title="Select input JSONL", filetypes=[("JSONL","*.jsonl;*.log;*.txt"),("All","*.*")])
        if path:
            self.in_var.set(path)

    def pick_output(self):
        path = filedialog.asksaveasfilename(title="Select output JSON", defaultextension=".json",
                                            filetypes=[("JSON","*.json"),("All","*.*")])
        if path:
            self.out_var.set(path)

    def run_extract(self):
        exe = self.exe_var.get().strip()
        inp = self.in_var.get().strip()
        outp = self.out_var.get().strip()

        if not exe:
            messagebox.showerror("Missing", "Select acars_parser executable.")
            return
        if not os.path.exists(exe):
            messagebox.showerror("Not found", f"Executable not found:\n{exe}")
            return
        if not inp:
            messagebox.showerror("Missing", "Select input JSONL.")
            return
        if not os.path.exists(inp):
            messagebox.showerror("Not found", f"Input not found:\n{inp}")
            return
        if not outp:
            messagebox.showerror("Missing", "Select output JSON.")
            return

        args = [exe, "extract", "-input", inp, "-output", outp]
        if self.pretty_var.get():
            args.append("-pretty")
        if self.all_var.get():
            args.append("-all")
        if getattr(self, 'stats_var', None) is not None and self.stats_var.get():
            args.append("-stats")

        self.txt.delete("1.0", "end")
        self.txt.insert("end", "Running:\n" + " ".join(args) + "\n\n")

        def worker():
            try:
                # On Windows you can add creationflags to hide extra console window:
                creationflags = 0
                if os.name == "nt":
                    creationflags = subprocess.CREATE_NO_WINDOW  # type: ignore[attr-defined]
                p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                     creationflags=creationflags)
                assert p.stdout is not None
                for line in p.stdout:
                    self._append(line)
                rc = p.wait()
                self._append(f"\nDone. Exit code: {rc}\nOutput: {outp}\n")
            except Exception as e:
                self._append(f"\nERROR: {e}\n")

        threading.Thread(target=worker, daemon=True).start()

    def _append(self, s: str):
        # thread-safe-ish UI update
        def _do():
            self.txt.insert("end", s)
            self.txt.see("end")
        self.after(0, _do)

if __name__ == "__main__":
    App().mainloop()
